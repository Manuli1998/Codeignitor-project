-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 28, 2020 at 12:41 PM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.4.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `myapp`
--

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(50) NOT NULL,
  `address` varchar(100) NOT NULL,
  `password` varchar(20) DEFAULT NULL,
  `mobile` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `address`, `password`, `mobile`) VALUES
(94, 'Manuli Wanniarachchi', 'manuli@gmail.com', 'Anderson Flats, Narahenpita', 'mAnu@1234', 712966301),
(95, 'Buddhi Wickramasinghe', 'buddhi1998@gmail.com', 'Thalahena,malabe', 'buddhicw', 712966301),
(96, 'Thamara Athukorala', 'thamara@gmail.com', 'Narahenpita, Colombo 05', 'thamara@1234', 778077942),
(100, 'Chathura Rathnayake', 'chathu@gmail.com', 'No.456/7, Rathnapura', 'chathurarathnayake', 112789789),
(108, 'Iranga  Mudalige', 'ira@gmail.com', 'No.26.5, Kuruwita', 'ira#123', 708908762),
(109, 'Shyamalee Pathirana', 'shyamalee@gmail.com', 'No.12/3, Mathugama,Kalutara', 'sha@1234', 112344567),
(111, 'Prasanna Kumara', 'prasaku@gmail.com', 'no.26/7 Flower Road,Galle', 'prasa@1234', 724357080),
(112, 'Nihansa Binadi', 'nihansa@gmail.com', 'Colombo', 'beena', 715626747),
(113, 'Niluja Wimalarathne', 'niluja@gmail.com', 'Ja-ela, Colombo', '2005', 764565678),
(114, 'Ajith Sooriyaarachchi', 'ajith@gmail.com', 'Matara', 'ajith@1234', 719522708),
(115, 'Dilanka Perera', 'dila@gmail.com', 'No.23/6 Koranelis Mawatha, Nugegoda', 'dila@123', 786787896);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=116;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
